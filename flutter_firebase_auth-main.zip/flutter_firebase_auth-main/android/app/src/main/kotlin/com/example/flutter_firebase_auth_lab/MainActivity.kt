package com.example.flutter_firebase_auth_lab

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
