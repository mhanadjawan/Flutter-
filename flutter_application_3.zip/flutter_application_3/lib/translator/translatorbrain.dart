
class TranslatorBrain {
 
}
