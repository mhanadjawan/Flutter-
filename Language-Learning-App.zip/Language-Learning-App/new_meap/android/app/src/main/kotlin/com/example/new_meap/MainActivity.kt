package com.example.new_meap

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
